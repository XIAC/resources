"Central configuration"
import os

PHOTOS_BUCKET = os.environ['PHOTOS_BUCKET']
FLASK_SECRET = os.environ['FLASK_SECRET']
